import pandas as pd
from pathlib import Path

# Setup paths relative to the script location
BASE_DIR = Path(__file__).parent.resolve()
OUTPUT_DIR = BASE_DIR / "Output"

flows_file = OUTPUT_DIR / "flows.csv"
npv_file = OUTPUT_DIR / "npv.csv"

def reconcile_pricing():
    # 1. Load the ORE output reports
    if not flows_file.exists() or not npv_file.exists():
        print("Error: ORE output files not found. Please run run_pricing.py first.")
        return

    # Load dataframes
    flows_df = pd.read_csv(flows_file)
    npv_df = pd.read_csv(npv_file)

    # 2. Clean column headers (strip whitespaces/pound symbols)
    flows_df.columns = [c.strip() for c in flows_df.columns]
    npv_df.columns = [c.strip() for c in npv_df.columns]

    # 3. Calculate manual PV for each cashflow: PV = Amount * DiscountFactor
    # Note: ORE already provides the Discount Factor (DF) for the payment date of each flow.
    flows_df["ManualPresentValue"] = flows_df["Amount"] * flows_df["DiscountFactor"]

    # 4. Verify manual PV matches ORE's reported PresentValue column
    pv_diffs = (flows_df["ManualPresentValue"] - flows_df["PresentValue"]).abs()
    max_pv_diff = pv_diffs.max()
    print(f"Max difference between manual calculation and ORE's PresentValue column: {max_pv_diff:.2e} EUR")

    # 5. Segment and group flows by Leg Number
    # Leg 0 is typically the fixed leg, Leg 1 is the floating leg (6M EURIBOR in this swap)
    leg_groups = flows_df.groupby("LegNo")

    print("\n=== Cashflow Leg Breakdown ===")
    leg_pvs = {}
    for leg_no, group in leg_groups:
        # Determine leg characteristics from first row
        first_row = group.iloc[0]
        flow_types = group["FlowType"].unique()
        currency = first_row["Currency"]
        
        # Sum the PV of the leg cashflows
        leg_pv = group["PresentValue"].sum()
        leg_pvs[leg_no] = leg_pv
        
        print(f"Leg {leg_no}:")
        print(f"  - Types of flows: {', '.join(flow_types)}")
        print(f"  - Currency: {currency}")
        print(f"  - Number of cashflows: {len(group)}")
        print(f"  - Total Leg PV: {leg_pv:,.4f} {currency}")

    # 6. Reconcile Net PV against headline NPV
    reconstructed_npv = flows_df["PresentValue"].sum()
    swap_row = npv_df[npv_df["#TradeId"] == "Swap_20y"]
    reported_npv = swap_row["NPV"].iloc[0]
    npv_currency = swap_row["NpvCurrency"].iloc[0]
    difference = reconstructed_npv - reported_npv

    print("\n=== PV Reconciliation Summary ===")
    print(f"Fixed Leg PV (Leg 0):     {leg_pvs.get(0, 0.0):,.4f} {npv_currency}")
    print(f"Floating Leg PV (Leg 1):  {leg_pvs.get(1, 0.0):,.4f} {npv_currency}")
    print("-" * 50)
    print(f"Reconstructed Net PV:     {reconstructed_npv:,.4f} {npv_currency}")
    print(f"ORE Reported NPV:         {reported_npv:,.4f} {npv_currency}")
    print(f"Reconciliation Residual:  {difference:.2e} {npv_currency}")
    print("-" * 50)

    # Assert tolerance of 1e-5 EUR
    tolerance = 1e-5
    if abs(difference) < tolerance:
        print("SUCCESS: The net cashflow PV matches the reported NPV exactly!")
    else:
        print("WARNING: There is a discrepancy between the sum of cashflow PVs and the reported NPV.")

if __name__ == "__main__":
    reconcile_pricing()
