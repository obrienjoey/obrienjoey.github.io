import os
import csv
import pandas as pd
import ORE as ore
from pathlib import Path
import xml.etree.ElementTree as ET

# Setup paths relative to the script location
BASE_DIR = Path(__file__).parent.resolve()
INPUT_DIR = BASE_DIR / "Input"
OUTPUT_DIR = BASE_DIR / "Output"

def reconcile_floating_rate_api():
    """Approach A: Direct Market Query via Python Bindings"""
    ore_xml_path = INPUT_DIR / "ore.xml"
    if not ore_xml_path.exists():
        print("Error: ore.xml not found in Input directory.")
        return

    tree = ET.parse(ore_xml_path)
    root = tree.getroot()

    for param in root.findall(".//Parameter"):
        name = param.get("name")
        if name == "inputPath":
            param.text = str(INPUT_DIR)
        elif name == "outputPath":
            param.text = str(OUTPUT_DIR)

    temp_ore_xml = BASE_DIR / "temp_ore_reconcile.xml"
    tree.write(temp_ore_xml, encoding="utf-8", xml_declaration=True)

    params = ore.Parameters()
    params.fromFile(str(temp_ore_xml))
    app = ore.OREApp(params)
    app.run()

    if temp_ore_xml.exists():
        os.remove(temp_ore_xml)

    analytic = app.getAnalytic("NPV")
    market = analytic.getMarket()

    eur_6m_forward = market.yieldCurve("EUR-EURIBOR-6M")
    eur_6m_idx = market.iborIndex("EUR-EURIBOR-6M")

    start_date = ore.Date(21, 2, 2025)
    end_date   = ore.Date(21, 8, 2025)

    day_counter = eur_6m_idx.dayCounter()
    tau = day_counter.yearFraction(start_date, end_date)

    df_start = eur_6m_forward.discount(start_date)
    df_end   = eur_6m_forward.discount(end_date)

    manual_fwd_rate = (df_start / df_end - 1.0) / tau
    notional = 10_000_000.00
    manual_amount = -1.0 * notional * manual_fwd_rate * tau

    print("\n=== Floating Rate Manual Projection (Approach A: Market API) ===")
    print(f"Start Date:       {start_date.ISO()} (DF = {df_start:.10f})")
    print(f"End Date:         {end_date.ISO()} (DF = {df_end:.10f})")
    print(f"Year Fraction:    {tau:.10f} ({day_counter.name()})")
    print("-" * 65)
    print(f"Calculated Rate:  {manual_fwd_rate*100:.8f}%")
    print(f"Calculated Flow:  {manual_amount:,.4f} EUR")


def reconcile_floating_rate_csv():
    """Approach B: Auditing directly from curves.csv Export"""
    curves_csv_path = OUTPUT_DIR / "curves.csv"
    if not curves_csv_path.exists():
        print(f"Error: {curves_csv_path} not found. Run ORE first.")
        return

    curves_df = pd.read_csv(curves_csv_path)
    curves_df.columns = [c.strip() for c in curves_df.columns]

    # ORE's curves report is wide: one discount-factor column per curve.
    # Select the EUR-EURIBOR-6M forward curve at the coupon accrual dates.
    df_start = curves_df.loc[curves_df["Date"].str.strip() == "2025-02-21", "EUR_EURIBOR_6M_DF"].values[0]
    df_end   = curves_df.loc[curves_df["Date"].str.strip() == "2025-08-21", "EUR_EURIBOR_6M_DF"].values[0]

    tau = 181.0 / 360.0
    notional = 10_000_000.00

    manual_fwd_rate = (df_start / df_end - 1.0) / tau
    manual_amount = -1.0 * notional * manual_fwd_rate * tau

    print("\n=== Floating Rate Manual Projection (Approach B: curves.csv) ===")
    print(f"Start Date:       2025-02-21 (DF = {df_start:.10f})")
    print(f"End Date:         2025-08-21 (DF = {df_end:.10f})")
    print(f"Year Fraction:    {tau:.10f} (181/360)")
    print("-" * 65)
    print(f"Calculated Rate:  {manual_fwd_rate*100:.8f}%")
    print(f"Calculated Flow:  {manual_amount:,.4f} EUR")


if __name__ == "__main__":
    reconcile_floating_rate_api()
    reconcile_floating_rate_csv()
