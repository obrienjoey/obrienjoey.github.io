import os
import ORE as ore
from pathlib import Path

# Setup paths relative to the script location
BASE_DIR = Path(__file__).parent.resolve()
INPUT_DIR = BASE_DIR / "Input"
OUTPUT_DIR = BASE_DIR / "Output"

os.makedirs(OUTPUT_DIR, exist_ok=True)

# Update the ore.xml paths programmatically to be absolute to avoid path mismatches
import xml.etree.ElementTree as ET
ore_xml_path = INPUT_DIR / "ore.xml"
tree = ET.parse(ore_xml_path)
root = tree.getroot()

for param in root.findall(".//Parameter"):
    name = param.get("name")
    if name == "inputPath":
        param.text = str(INPUT_DIR)
    elif name == "outputPath":
        param.text = str(OUTPUT_DIR)

# Write to a temp ore.xml file to run ORE
temp_ore_xml = BASE_DIR / "temp_ore.xml"
tree.write(temp_ore_xml, encoding="utf-8", xml_declaration=True)

# Run ORE
params = ore.Parameters()
params.fromFile(str(temp_ore_xml))
app = ore.OREApp(params)
app.run()

# Clean up temp file
if temp_ore_xml.exists():
    os.remove(temp_ore_xml)

print("\n--- ORE Swap Pricing Completed Successfully! ---")
print("NPV file generated at:", OUTPUT_DIR / "npv.csv")
print("Flows file generated at:", OUTPUT_DIR / "flows.csv")

# Print the NPV result
npv_file = OUTPUT_DIR / "npv.csv"
if npv_file.exists():
    import csv
    with open(npv_file, 'r') as f:
        reader = csv.DictReader(f)
        for row in reader:
            row = {k.strip(): v.strip() for k, v in row.items()}
            print(f"Trade: {row.get('#TradeId')}, Type: {row.get('TradeType')}, NPV: {row.get('NPV')} {row.get('NpvCurrency')}")
