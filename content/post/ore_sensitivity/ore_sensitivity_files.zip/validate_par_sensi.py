"""15Y manual bump-and-reval validation of ORE's Jacobian par deltas.

Bumps the 15Y EUR-ESTER OIS quote (IR_SWAP/RATE/EUR/ESTER/2D/1D/15Y) in
marketdata.csv by +1bp and -1bp, re-runs ORE NPV each time, and compares the
finite-difference deltas against the total par delta ORE's Jacobian conversion
reports in parsensitivity.csv.

Central difference is the primary check: it cancels the leading second-order
curvature term, so it isolates the slope at the point, which is the quantity the
linear Jacobian represents. Forward difference is kept as a secondary check to
show how much curvature leaks into a single-sided estimate (at 1bp here it is
small, so the two readings nearly agree).

Writes Output/bump_reval_15Y.csv so the published post numbers can be
re-verified mechanically. Requires Output/parsensitivity.csv, i.e. run
run_sensitivity.py first.
"""

import os
import sys
import xml.etree.ElementTree as ET
from pathlib import Path

import ORE as ore
import pandas as pd

BASE_DIR = Path(__file__).parent.resolve()
INPUT_DIR = BASE_DIR / "Input"
OUTPUT_DIR = BASE_DIR / "Output"

QUOTE_TO_BUMP = "IR_SWAP/RATE/EUR/ESTER/2D/1D/15Y"
BUMP_BP = 1.0
FACTORS_15Y = ("DiscountCurve/EUR/7/15Y", "IndexCurve/EUR-ESTER/7/15Y")


def run_npv_only() -> float:
    """Run ORE with the sensitivity analytic disabled and return trade NPV."""
    ore_xml = INPUT_DIR / "ore.xml"
    tree = ET.parse(ore_xml)
    root = tree.getroot()
    for param in root.findall(".//Parameter"):
        name = param.get("name")
        if name == "inputPath":
            param.text = str(INPUT_DIR)
        elif name == "outputPath":
            param.text = str(OUTPUT_DIR)
    for analytic in root.findall(".//Analytic"):
        if analytic.get("type") == "sensitivity":
            active = analytic.find("./Parameter[@name='active']")
            active.text = "N"

    temp_xml = BASE_DIR / "temp_ore.xml"
    tree.write(temp_xml, encoding="utf-8", xml_declaration=True)
    params = ore.Parameters()
    params.fromFile(str(temp_xml))
    app = ore.OREApp(params)
    app.run()
    temp_xml.unlink()

    npv = pd.read_csv(OUTPUT_DIR / "npv.csv")
    npv.columns = [c.strip() for c in npv.columns]
    return float(npv["NPV"].iloc[0])


def bump_quote(shift_bp: float) -> None:
    """Shift the 15Y OIS quote in marketdata.csv by shift_bp (keeps a backup)."""
    market_file = INPUT_DIR / "marketdata.csv"
    backup_file = INPUT_DIR / "marketdata.csv.bak"
    if not backup_file.exists():
        os.replace(market_file, backup_file)

    df = pd.read_csv(backup_file, header=None, names=["Date", "Quote", "Value"])
    mask = df["Quote"] == QUOTE_TO_BUMP
    if not mask.any():
        restore_market_data()
        sys.exit(f"Quote {QUOTE_TO_BUMP} not found in marketdata.csv")

    df.loc[mask, "Value"] = df.loc[mask, "Value"] + shift_bp * 1e-4
    df.to_csv(market_file, header=False, index=False)


def restore_market_data() -> None:
    backup_file = INPUT_DIR / "marketdata.csv.bak"
    if backup_file.exists():
        if (INPUT_DIR / "marketdata.csv").exists():
            (INPUT_DIR / "marketdata.csv").unlink()
        os.rename(backup_file, INPUT_DIR / "marketdata.csv")


def total_par_delta_15y() -> float:
    """Total par delta at 15Y = discount handle + index handle (per 1bp)."""
    par = pd.read_csv(OUTPUT_DIR / "parsensitivity.csv")
    par.columns = [c.strip() for c in par.columns]
    return sum(
        float(par[par["Factor_1"] == factor]["Delta"].iloc[0]) for factor in FACTORS_15Y
    )


def main() -> int:
    if not (OUTPUT_DIR / "parsensitivity.csv").exists():
        print("Error: Output/parsensitivity.csv not found; run run_sensitivity.py first.")
        return 1

    print("--- 15Y Manual Bump-and-Reval Validation ---")
    print(f"Quote bumped: {QUOTE_TO_BUMP} (+/- {BUMP_BP} bp)\n")

    print("[1/3] Base NPV (sensitivity analytic disabled)...")
    base_npv = run_npv_only()
    print(f"      Base NPV: {base_npv:,.4f} EUR\n")

    print(f"[2/3] Bumping quote +{BUMP_BP} bp and re-valuing...")
    try:
        bump_quote(+BUMP_BP)
        plus_npv = run_npv_only()

        print(f"[3/3] Bumping quote -{BUMP_BP} bp and re-valuing...")
        bump_quote(-BUMP_BP)
        minus_npv = run_npv_only()
    finally:
        restore_market_data()

    forward_delta = plus_npv - base_npv
    central_delta = (plus_npv - minus_npv) / 2.0
    gamma_1bp = plus_npv + minus_npv - 2.0 * base_npv

    par_total = total_par_delta_15y()

    print("\n=== Validation Results ===")
    print(f"Base NPV:                       {base_npv:>14,.4f} EUR")
    print(f"NPV at +1bp:                    {plus_npv:>14,.4f} EUR")
    print(f"NPV at -1bp:                    {minus_npv:>14,.4f} EUR")
    print(f"Forward difference delta:       {forward_delta:>14,.4f} EUR")
    print(f"Central difference delta:       {central_delta:>14,.4f} EUR")
    print(f"Curvature term (V+ + V- - 2V0): {gamma_1bp:>14,.4f} EUR")
    print(f"ORE total par delta at 15Y:     {par_total:>14,.4f} EUR")
    print()

    summary_rows = [
        ("central", central_delta, central_delta - par_total),
        ("forward", forward_delta, forward_delta - par_total),
    ]
    print(f"{'Check':<12s}{'FD delta (EUR)':>18s}{'Abs diff vs par (EUR)':>24s}{'Rel diff':>12s}")
    for label, delta, diff in summary_rows:
        rel = abs(diff) / abs(par_total) * 100.0
        print(f"{label:<12s}{delta:>18,.2f}{diff:>24,.2f}{rel:>11.3f}%")

    result = {
        "quote": QUOTE_TO_BUMP,
        "bump_bp": BUMP_BP,
        "base_npv": base_npv,
        "npv_plus_1bp": plus_npv,
        "npv_minus_1bp": minus_npv,
        "forward_delta": forward_delta,
        "central_delta": central_delta,
        "gamma_1bp": gamma_1bp,
        "par_delta_total_15y": par_total,
        "central_abs_diff": central_delta - par_total,
        "forward_abs_diff": forward_delta - par_total,
    }
    out_file = OUTPUT_DIR / "bump_reval_15Y.csv"
    pd.DataFrame([result]).to_csv(out_file, index=False)
    print(f"\nResults written to {out_file}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
