import os
import ORE as ore
from pathlib import Path
import xml.etree.ElementTree as ET
import pandas as pd

BASE_DIR = Path(__file__).parent.resolve()
INPUT_DIR = BASE_DIR / "Input"
OUTPUT_DIR = BASE_DIR / "Output"

def run_ore_sensitivity():
    print("--- Running ORE Sensitivity Analysis ---")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # Update the ore.xml paths programmatically to be absolute
    ore_xml_path = INPUT_DIR / "ore.xml"
    tree = ET.parse(ore_xml_path)
    root = tree.getroot()

    for param in root.findall(".//Parameter"):
        name = param.get("name")
        if name == "inputPath":
            param.text = str(INPUT_DIR)
        elif name == "outputPath":
            param.text = str(OUTPUT_DIR)

    temp_ore_xml = BASE_DIR / "temp_ore.xml"
    tree.write(temp_ore_xml, encoding="utf-8", xml_declaration=True)

    # Run ORE
    params = ore.Parameters()
    params.fromFile(str(temp_ore_xml))
    app = ore.OREApp(params)
    app.run()

    if temp_ore_xml.exists():
        os.remove(temp_ore_xml)
    print("--- ORE Sensitivity Run Completed ---\n")

def display_results():
    sensi_file = OUTPUT_DIR / "sensitivity.csv"
    par_sensi_file = OUTPUT_DIR / "parsensitivity.csv"
    
    if not sensi_file.exists():
        print(f"Error: {sensi_file} not found!")
        return

    # Load zero sensitivities
    df_zero = pd.read_csv(sensi_file)
    df_zero.columns = [c.strip() for c in df_zero.columns]
    
    print("=== Zero-Domain Sensitivities (sensitivity.csv) ===")
    print(df_zero.to_string(index=False))
    print()

    # Load par sensitivities
    if par_sensi_file.exists():
        df_par = pd.read_csv(par_sensi_file)
        df_par.columns = [c.strip() for c in df_par.columns]
        print("=== Par-Domain Sensitivities (parsensitivity.csv) ===")
        print(df_par.to_string(index=False))
        print()
        
        # Calculate totals
        zero_total = df_zero["Delta"].sum() if "Delta" in df_zero.columns else 0.0
        par_total = df_par["Delta"].sum() if "Delta" in df_par.columns else 0.0
        print(f"Total Zero Delta (DV01): {zero_total:,.4f}")
        print(f"Total Par Delta (DV01):  {par_total:,.4f}")
        print(f"Difference:              {abs(zero_total - par_total):,.4f}")
        print()
    else:
        print("Warning: parsensitivity.csv not found!")

if __name__ == "__main__":
    run_ore_sensitivity()
    display_results()
